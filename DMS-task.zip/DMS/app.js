$(".second-section").click(function() {
    $("#mySidenav").addClass("col-2");
    $("#content").removeClass("col-11");
    $(".page-inputs").removeClass("col-11");
    $("#content").addClass("col-10");
    $(".second-section").css("display", "none");

});

$(".closebtn").click(function() {
    $("#mySidenav").removeClass("col-2");
    $("#mySidenav").removeClass("col-10");
    $("#content").addClass("col-11");
    setTimeout(function() {
        $(".second-section").css("display", "block");
    }, 500);



});

$(document).ready(function() {
    console.log($(document).height());
    $(".sidenav").css("height", $(window).height());
});